<?php
/***************************************************************************
 *                                                                          *
 *   (c) 2004 Vladimir V. Kalynyak, Alexey V. Vinokurov, Ilya M. Shalnev    *
 *                                                                          *
 * This  is  commercial  software,  only  users  who have purchased a valid *
 * license  and  accept  to the terms of the  License Agreement can install *
 * and use this program.                                                    *
 *                                                                          *
 ****************************************************************************
 * PLEASE READ THE FULL TEXT  OF THE SOFTWARE  LICENSE   AGREEMENT  IN  THE *
 * "copyright.txt" FILE PROVIDED WITH THIS DISTRIBUTION PACKAGE.            *
 ****************************************************************************/

use Tygh\Registry;

defined('BOOTSTRAP') or die('Access denied');

/**
 * The "place_order_post" hook handler.
 *
 * Actions performed:
 * - Changes status of all placed orders to Open.
 *
 * @param array    $cart               Cart content
 * @param array    $auth               Authentication data
 * @param string   $action             Order placement action
 * @param int|null $issuer_id          Order manager user ID
 * @param int      $parent_order_id    Parent order ID
 * @param int      $order_id           Placed order ID
 * @param string   $order_status       Current status of order
 * @param array    $short_order_data   Short order data
 * @param array    $notification_rules Notification rules
 *
 * @return void
 *
 * @see \fn_place_order()
 */
function fn_open_placed_orders_place_order_post(
    $cart,
    $auth,
    $action,
    $issuer_id,
    $parent_order_id,
    $order_id,
    $order_status,
    $short_order_data,
    $notification_rules
) {
    if ($order_status === 'O') {
        return;
    }

    fn_change_order_status($order_id, 'O', $order_status, $notification_rules, true);
}

/**
 * The "change_order_status_before_update_product_amount" hook handler.
 *
 * Actions performed:
 * - Locks product amount update process to the current request to prevent parallel conflicting updates.
 *
 * @see \fn_change_order_status()
 */
function fn_open_placed_orders_change_order_status_before_update_product_amount(
    $order_id,
    $status_to,
    $status_from,
    $force_notification,
    $place_order,
    $order_info,
    $k,
    $v
) {
    $product_id = $v['product_id'];

    /** @var \Tygh\Lock\Factory $lock_factory */
    $lock_factory = Tygh::$app['lock.factory'];
    $lock = $lock_factory->createLock('product_update_amount_' . $product_id, 30.0, false);
    if ($lock->acquire()) {
        Registry::set('open_placed_orders.locks.product_update_amount_' . $product_id, $lock, true);

        return;
    }

    $lock->wait();
}

/**
 * The "orders_change_order_status" hook handler.
 *
 * Actions performed:
 * - Unlocks product updates from the current request.
 *
 * @see \fn_change_order_status()
 */
function fn_open_placed_orders_change_order_status(
    $status_to,
    $status_from,
    $order_info,
    $force_notification,
    $order_statuses,
    $place_order
) {
    foreach ($order_info['products'] as $product) {
        $product_id = $product['product_id'];
        $lock = Registry::get('open_placed_orders.locks.product_update_amount_' . $product_id);
        if (!$lock) {
            continue;
        }
        /** @var \Tygh\Lock\Lock $lock */
        $lock->release();
    }

    Registry::del('open_placed_orders.locks');
}
